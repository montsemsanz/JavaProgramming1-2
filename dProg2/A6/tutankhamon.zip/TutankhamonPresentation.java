/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 *                                                         *
 * Anvendelse:  Java-kursus p� Systematic, F2000           *
 *                                                         *
 * Beskrivelse: Denne fil indeholder klassen Tutankhamon-  *
 *              Presentation der er en specialisering af   *
 *              ImagePresenter (framework).                *
 *                                                         *
 * Oprettet:    29. januar 2000, Michael E. Caspersen      *
 *                                                         *
 * Modificeret: -                                          *
 *                                                         *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

import java.util.Vector;
import java.io.*;

import media.*;

// Finally this class models the whole multimedia presentation.
public class TutankhamonPresentation extends ImagePresenter {
  // Association 1-1 to the 'virtual' Visitor that represents the
  // user in the virtual tomb.
  Visitor       guest;
  
  // Override the applets init metod to get things going.
  // "init" is for applets what "main" is for textual programs.
  public void init() {
    guest = new Visitor( this );
    setupRooms();
  }

  // Create rooms according to the layout of Pharao Tutankhamons tomb
  public void setupRooms() {
    Room staircase, antechamber, annex, tomb, treasury;

    staircase = new Room("You are on a brightly sunlit descending staircase "+
                         "leading NORTH and down.",
                         "tutstaircase1.jpg"  );
  
    antechamber = new Room("You are a dark room known as the antechamber. "+
                           "There are a lot of precious antiques here, but "+
                           "the room is "+
                           "dominated by three large wooden royal beds, shaped "+
                           "as lions and plated with gold",
                           "tutantechamber.jpg" );

    annex = new Room( "You are in the annex full of 3500 years old food",
                      "tutannex.jpg"  );

    tomb = new Room( "You are in the burial chamber of Tutankhamon. "+
                     "The sarcophagus fills "+
                     "most of the room barely leaving room for you.",
                     "tutburial.jpg" );

    treasury = new Room( "You are in the treasury. It is dominated by a large "+
                         "wooden figure of the Anubis good in front. Behind it "+
                         "you can see a beautiful golden shrine.",
                         "tuttreasury.jpg"  );

    // --- and connect them properly
    staircase.connectTo( antechamber, Direction.NORTH );
  
    antechamber.connectTo( staircase, Direction.SOUTH );
    antechamber.connectTo( annex, Direction.NORTH );
    antechamber.connectTo( tomb, Direction.EAST );
  
    annex.connectTo( antechamber, Direction.SOUTH );

    tomb.connectTo( antechamber, Direction.WEST );
    tomb.connectTo( treasury, Direction.SOUTH );

    treasury.connectTo( tomb, Direction.NORTH );

    // Finally we set the Visitor at the staircase
    guest.setAt( staircase );
  }

  // These methods specialise the framework for our purpose.
  public void northButtonPressed() {
    guest.move(Direction.NORTH);
  }
  public void eastButtonPressed() { 
    guest.move(Direction.EAST);
  }
  public void southButtonPressed() {
    guest.move(Direction.SOUTH);
  }
  public void westButtonPressed() { 
    guest.move(Direction.WEST);
  }
}